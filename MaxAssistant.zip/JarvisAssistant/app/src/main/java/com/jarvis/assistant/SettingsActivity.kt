package com.jarvis.assistant

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val saveButton = findViewById<Button>(R.id.saveButton)

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        apiKeyInput.setText(prefs.getString(KEY_API_KEY, ""))

        saveButton.setOnClickListener {
            prefs.edit().putString(KEY_API_KEY, apiKeyInput.text.toString().trim()).apply()
            Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    companion object {
        const val PREFS_NAME = "jarvis_prefs"
        const val KEY_API_KEY = "gemini_api_key"
    }
}
