package com.jarvis.assistant

/**
 * Cleans AI-generated text before it's passed to TextToSpeech, so Max
 * speaks only the actual point — no links read out, no emoji noises,
 * no markdown symbols.
 */
object SpeechTextUtils {

    private val urlPattern = Regex("(https?://\\S+|www\\.\\S+)")
    private val emojiPattern = Regex(
        "[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{1F1E6}-\\x{1F1FF}\\x{2B00}-\\x{2BFF}\\x{FE0F}\\x{200D}]"
    )
    private val markdownPattern = Regex("[*_#`~]")

    fun cleanForSpeech(text: String): String {
        var cleaned = text.replace(urlPattern, "")
        cleaned = cleaned.replace(emojiPattern, "")
        cleaned = cleaned.replace(markdownPattern, "")
        cleaned = cleaned.replace(Regex("\\s+"), " ").trim()
        return cleaned
    }
}
