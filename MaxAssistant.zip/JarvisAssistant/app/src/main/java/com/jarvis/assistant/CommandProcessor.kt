package com.jarvis.assistant

import android.content.Context

/**
 * Basic keyword-based intent matching. This is intentionally simple (not full NLU)
 * so it works instantly and offline for common commands. Anything it doesn't
 * recognize falls through to the Gemini chat brain in MainActivity.
 */
class CommandProcessor(private val context: Context) {

    fun process(input: String): String? {
        val text = input.trim()
        val lower = text.lowercase()

        callPattern.find(lower)?.let { match ->
            val name = extractName(text, match.range.last + 1)
            return PhoneActions.makeCall(context, name)
        }

        messagePattern.find(lower)?.let { match ->
            val name = extractName(text, match.range.last + 1)
            return PhoneActions.openSmsApp(context, name, "")
        }

        openAppPattern.find(lower)?.let { match ->
            val appName = extractName(text, match.range.last + 1)
            return PhoneActions.openApp(context, appName)
        }

        if (lower.contains("alarm")) {
            return PhoneActions.openAlarmScreen(context)
        }

        searchPattern.find(lower)?.let { match ->
            val before = text.substring(0, match.range.first).trim()
            val after = text.substring(match.range.last + 1).trim()
            val query = before.ifEmpty { after }.ifEmpty { text }
            return PhoneActions.webSearch(context, query)
        }

        return null
    }

    private fun extractName(original: String, fromIndex: Int): String {
        val raw = if (fromIndex < original.length) original.substring(fromIndex) else original
        return raw.replace(Regex("\\bko\\b|\\bkaro\\b|\\bkar do\\b|\\bkholo\\b"), "")
            .trim()
            .ifEmpty { original.trim() }
    }

    companion object {
        private val callPattern = Regex("\\bcall\\b")
        private val messagePattern = Regex("\\bmessage\\b|\\bmsg\\b|\\bsms\\b")
        private val openAppPattern = Regex("\\bopen\\b|\\bkholo\\b|\\bkhol do\\b")
        private val searchPattern = Regex("\\bsearch\\b")
    }
}
