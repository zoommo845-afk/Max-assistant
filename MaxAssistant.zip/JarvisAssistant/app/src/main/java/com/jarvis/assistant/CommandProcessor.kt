package com.jarvis.assistant

import android.content.Context

/**
 * Basic keyword-based intent matching. Handles both English word order
 * ("call Mummy", "open WhatsApp") and Hindi/Hinglish word order
 * ("Mummy ko call karo", "WhatsApp kholo") by checking for the target
 * name on both sides of the matched command keyword.
 */
class CommandProcessor(private val context: Context) {

    fun process(input: String): String? {
        val text = input.trim()
        val lower = text.lowercase()

        callPattern.find(lower)?.let { match ->
            return PhoneActions.makeCall(context, extractTarget(text, match))
        }

        messagePattern.find(lower)?.let { match ->
            return PhoneActions.openSmsApp(context, extractTarget(text, match), "")
        }

        openAppPattern.find(lower)?.let { match ->
            return PhoneActions.openApp(context, extractTarget(text, match))
        }

        if (lower.contains("alarm")) {
            return PhoneActions.openAlarmScreen(context)
        }

        searchPattern.find(lower)?.let { match ->
            return PhoneActions.webSearch(context, extractTarget(text, match))
        }

        return null
    }

    private fun extractTarget(text: String, match: MatchResult): String {
        val before = text.substring(0, match.range.first).trim()
        val after = if (match.range.last + 1 < text.length) {
            text.substring(match.range.last + 1).trim()
        } else ""

        val raw = before.ifEmpty { after }.ifEmpty { text }
        return raw.replace(fillerWords, "").trim().ifEmpty { text.trim() }
    }

    companion object {
        private val callPattern = Regex("\\bcall\\b")
        private val messagePattern = Regex("\\bmessage\\b|\\bmsg\\b|\\bsms\\b")
        private val openAppPattern = Regex("\\bopen\\b|\\bkholo\\b|\\bkhol do\\b")
        private val searchPattern = Regex("\\bsearch\\b")
        private val fillerWords = Regex(
            "\\bko\\b|\\bkaro\\b|\\bkar do\\b|\\bkijiye\\b|\\bkholo\\b|\\bkhol do\\b",
            RegexOption.IGNORE_CASE
        )
    }
}
