package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * Keeps listening in the background. Says nothing until it hears the
 * wake word "Max" — then replies "Jee boss, boliye" and listens for the
 * actual command. This requires a persistent notification because Android
 * does not allow silent background microphone access.
 */
class WakeWordService : Service() {

    private lateinit var voiceManager: VoiceManager
    private lateinit var commandProcessor: CommandProcessor
    private val handler = Handler(Looper.getMainLooper())
    private var awaitingCommand = false

    override fun onCreate() {
        super.onCreate()
        commandProcessor = CommandProcessor(this)
        voiceManager = VoiceManager(
            context = this,
            onResult = { text -> handleResult(text) },
            onListeningStateChanged = { }
        )
        startForeground(NOTIFICATION_ID, buildNotification("\"Max\" bolne ka wait kar rahi hoon..."))
        scheduleNextListen(300)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun scheduleNextListen(delayMs: Long) {
        handler.postDelayed({ voiceManager.startListening() }, delayMs)
    }

    private fun handleResult(text: String) {
        if (text.isBlank()) {
            scheduleNextListen(700)
            return
        }

        val lower = text.lowercase()

        if (!awaitingCommand) {
            if (lower.contains("max")) {
                awaitingCommand = true
                updateNotification("Sun rahi hoon, boliye...")
                voiceManager.speak("Jee boss, boliye")
                scheduleNextListen(1800)
            } else {
                scheduleNextListen(700)
            }
            return
        }

        awaitingCommand = false
        updateNotification("\"Max\" bolne ka wait kar rahi hoon...")

        val phoneTaskReply = commandProcessor.process(text)
        if (phoneTaskReply != null) {
            speakAndContinue(phoneTaskReply)
            return
        }

        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val apiKey = prefs.getString(SettingsActivity.KEY_API_KEY, "") ?: ""
        if (apiKey.isBlank()) {
            speakAndContinue("Pehle app kholke Settings mein API key daal do")
            return
        }

        GeminiClient(apiKey).ask(text) { reply ->
            handler.post { speakAndContinue(reply) }
        }
    }

    private fun speakAndContinue(reply: String) {
        val spoken = SpeechTextUtils.cleanForSpeech(reply)
        if (spoken.isNotBlank()) {
            voiceManager.speak(spoken)
        }
        scheduleNextListen(if (spoken.isNotBlank()) 2500 else 700)
    }

    private fun buildNotification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Max Background Listening", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Max Assistant")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        voiceManager.destroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "max_wake_word_channel"
    }
}
