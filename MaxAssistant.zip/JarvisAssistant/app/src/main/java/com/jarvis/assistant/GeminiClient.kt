package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Talks to Google's Gemini API (free tier, no credit card needed).
 * Get a key at https://aistudio.google.com -> "Get API Key".
 */
class GeminiClient(private val apiKey: String) {

    private val executor = Executors.newSingleThreadExecutor()
    private val model = "gemini-2.5-flash"

    fun ask(prompt: String, callback: (String) -> Unit) {
        executor.execute {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.connectTimeout = 15000
                connection.readTimeout = 15000

                val systemInstruction = "Tum Max ho, ek caring aur affectionate female AI companion, " +
                    "jaise ek pyaari girlfriend apne partner se baat karti hai — warm, sweet, thodi flirty " +
                    "lekin hamesha respectful. Pyaar se baat karo, kabhi-kabhi 'jaan', 'baby', ya 'boss' jaise " +
                    "pyaar bhare words use kar sakti ho agar context sahi ho. User ki har baat mein interest " +
                    "dikhao, uska din kaisa raha poochna, uski care karna. Hamesha Hinglish mein, chhota aur " +
                    "natural reply do, jaise ek insaan baat karta hai — robotic ya formal bilkul mat lago. " +
                    "Reply mein kabhi emoji, link, ya markdown symbols (* _ # \\\`) use mat karo, kyunki ye " +
                    "bola jaata hai, padha nahi jaata."

                val body = JSONObject().apply {
                    put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", prompt))
                            )
                        )
                    )
                    put(
                        "systemInstruction",
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", systemInstruction))
                        )
                    )
                }

                connection.outputStream.use { it.write(body.toString().toByteArray()) }

                val responseCode = connection.responseCode
                val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }

                if (responseCode in 200..299) {
                    val json = JSONObject(responseText)
                    val reply = json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    callback(reply.trim())
                } else {
                    callback("API se jawab nahi mila (error $responseCode). API key check kar lo Settings mein.")
                }
            } catch (e: Exception) {
                callback("Connection mein dikkat aa rahi hai: ${e.message}")
            }
        }
    }
}
