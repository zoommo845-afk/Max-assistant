package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Talks to Google's Gemini API (free tier, no credit card needed).
 * Get a key at https://aistudio.google.com -> "Get API Key".
 */
class GeminiClient(private val apiKey: String) {

    private val executor = Executors.newSingleThreadExecutor()
    private val model = "gemini-2.5-flash"

    fun ask(prompt: String, callback: (String) -> Unit) {
        executor.execute {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.connectTimeout = 15000
                connection.readTimeout = 15000

                val systemInstruction = "Tum ek dost jaisi female AI assistant ho jiska naam Max hai. " +
                    "Hamesha Hinglish mein, chhota aur natural reply do, jaise ek insaan baat karta hai."

                val body = JSONObject().apply {
                    put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", prompt))
                            )
                        )
                    )
                    put(
                        "systemInstruction",
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", systemInstruction))
                        )
                    )
                }

                connection.outputStream.use { it.write(body.toString().toByteArray()) }

                val responseCode = connection.responseCode
                val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }

                if (responseCode in 200..299) {
                    val json = JSONObject(responseText)
                    val reply = json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    callback(reply.trim())
                } else {
                    callback("API se jawab nahi mila (error $responseCode). API key check kar lo Settings mein.")
                }
            } catch (e: Exception) {
                callback("Connection mein dikkat aa rahi hai: ${e.message}")
            }
        }
    }
}
