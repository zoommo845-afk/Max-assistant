package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract

/**
 * Performs real actions on the phone. Each function returns a short Hinglish
 * confirmation string that gets spoken back to the user.
 */
object PhoneActions {

    fun makeCall(context: Context, nameOrNumber: String): String {
        val number = resolveNumber(context, nameOrNumber) ?: nameOrNumber
        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            "$nameOrNumber ko call kar rahi hoon"
        } catch (e: SecurityException) {
            "Mujhe call karne ki permission nahi mili, app settings mein permission de do"
        }
    }

    fun openSmsApp(context: Context, nameOrNumber: String, message: String): String {
        val number = resolveNumber(context, nameOrNumber) ?: nameOrNumber
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
            putExtra("sms_body", message)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return "$nameOrNumber ke liye message taiyaar kar diya, bas send dabana hai"
    }

    private fun resolveNumber(context: Context, name: String): String? {
        if (context.checkSelfPermission(android.Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return null

        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                return it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
            }
        }
        return null
    }

    fun openApp(context: Context, appName: String): String {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull { app ->
            pm.getApplicationLabel(app).toString().contains(appName, ignoreCase = true)
        }
        return if (match != null) {
            val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            if (launchIntent != null) {
                context.startActivity(launchIntent)
                "$appName khol rahi hoon"
            } else {
                "$appName ko khol nahi payi"
            }
        } else {
            "Mujhe $appName naam ka app nahi mila"
        }
    }

    fun openAlarmScreen(context: Context): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return "Alarm screen khol rahi hoon, time set kar lo"
    }

    fun webSearch(context: Context, query: String): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return "$query search kar rahi hoon"
    }
}
