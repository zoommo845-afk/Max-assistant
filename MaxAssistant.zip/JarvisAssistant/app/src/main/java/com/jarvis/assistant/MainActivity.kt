package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var voiceManager: VoiceManager
    private lateinit var commandProcessor: CommandProcessor
    private lateinit var conversationText: TextView
    private lateinit var statusText: TextView
    private lateinit var backgroundButton: Button
    private var backgroundModeOn = false

    private val requiredPermissions = mutableListOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        conversationText = findViewById(R.id.conversationText)
        statusText = findViewById(R.id.statusText)
        val micButton = findViewById<Button>(R.id.micButton)
        val settingsButton = findViewById<Button>(R.id.settingsButton)
        backgroundButton = findViewById(R.id.backgroundButton)

        commandProcessor = CommandProcessor(this)
        voiceManager = VoiceManager(
            context = this,
            onResult = { text -> handleSpokenText(text) },
            onListeningStateChanged = { isListening ->
                statusText.text = if (isListening) "Sun rahi hoon..." else "Tap the mic and speak"
            }
        )

        requestNeededPermissions()

        micButton.setOnClickListener {
            if (hasAllPermissions()) {
                voiceManager.startListening()
            } else {
                requestNeededPermissions()
            }
        }

        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        backgroundButton.setOnClickListener {
            if (!hasAllPermissions()) {
                requestNeededPermissions()
                return@setOnClickListener
            }
            toggleBackgroundMode()
        }

        appendLine("Max: Hi, main Max hoon. Kaise madad karoon?")
        voiceManager.speak("Hi, main Max hoon. Kaise madad karoon?")
    }

    private fun toggleBackgroundMode() {
        val serviceIntent = Intent(this, WakeWordService::class.java)
        if (!backgroundModeOn) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            backgroundModeOn = true
            backgroundButton.text = "Background Mode: ON (bolo \"Max\")"
        } else {
            stopService(serviceIntent)
            backgroundModeOn = false
            backgroundButton.text = "Background Mode: OFF"
        }
    }

    private fun handleSpokenText(text: String) {
        if (text.isBlank()) return
        appendLine("Tum: $text")

        val phoneTaskReply = commandProcessor.process(text)
        if (phoneTaskReply != null) {
            respond(phoneTaskReply)
            return
        }

        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val apiKey = prefs.getString(SettingsActivity.KEY_API_KEY, "") ?: ""

        if (apiKey.isBlank()) {
            respond("Pehle Settings mein apni free Gemini API key daal do, fir hum baat kar sakte hain")
            return
        }

        GeminiClient(apiKey).ask(text) { reply ->
            runOnUiThread { respond(reply) }
        }
    }

    private fun respond(text: String) {
        appendLine("Max: $text")
        val spoken = SpeechTextUtils.cleanForSpeech(text)
        if (spoken.isNotBlank()) {
            voiceManager.speak(spoken)
        }
    }

    private fun appendLine(line: String) {
        conversationText.append("\n$line")
    }

    private fun hasAllPermissions(): Boolean = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
