package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var voiceManager: VoiceManager
    private lateinit var commandProcessor: CommandProcessor
    private lateinit var conversationText: TextView
    private lateinit var statusText: TextView

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        conversationText = findViewById(R.id.conversationText)
        statusText = findViewById(R.id.statusText)
        val micButton = findViewById<Button>(R.id.micButton)
        val settingsButton = findViewById<Button>(R.id.settingsButton)

        commandProcessor = CommandProcessor(this)
        voiceManager = VoiceManager(
            context = this,
            onResult = { text -> handleSpokenText(text) },
            onListeningStateChanged = { isListening ->
                statusText.text = if (isListening) "Sun rahi hoon..." else "Tap the mic and speak"
            }
        )

        requestNeededPermissions()

        micButton.setOnClickListener {
            if (hasAllPermissions()) {
                voiceManager.startListening()
            } else {
                requestNeededPermissions()
            }
        }

        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        appendLine("Max: Hi, main Max hoon. Kaise madad karoon?")
        voiceManager.speak("Hi, main Max hoon. Kaise madad karoon?")
    }

    private fun handleSpokenText(text: String) {
        if (text.isBlank()) return
        appendLine("Tum: $text")

        val phoneTaskReply = commandProcessor.process(text)
        if (phoneTaskReply != null) {
            respond(phoneTaskReply)
            return
        }

        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val apiKey = prefs.getString(SettingsActivity.KEY_API_KEY, "") ?: ""

        if (apiKey.isBlank()) {
            respond("Pehle Settings mein apni free Gemini API key daal do, fir hum baat kar sakte hain")
            return
        }

        GeminiClient(apiKey).ask(text) { reply ->
            runOnUiThread { respond(reply) }
        }
    }

    private fun respond(text: String) {
        appendLine("Max: $text")
        voiceManager.speak(text)
    }

    private fun appendLine(line: String) {
        conversationText.append("\n$line")
    }

    private fun hasAllPermissions(): Boolean = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
