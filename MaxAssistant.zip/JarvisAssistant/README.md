# Max Assistant (Android)

Ek voice-based personal assistant: bolke baat karo, female voice mein reply milega, aur
phone ke kuch kaam (call, SMS, app kholna, alarm, web search) voice command se ho jaayenge.
Baaki sab baatcheet Google ke **free Gemini API** se hoti hai (no credit card chahiye).

## Step 1: Android Studio install karo
- https://developer.android.com/studio se free download karo (Windows/Mac/Linux).
- Pehli baar khulne par SDK download hone dena, internet chahiye hoga.

## Step 2: Project kholo
- Android Studio mein **Open** karo aur ye `JarvisAssistant` folder select karo.
- Gradle sync hone do (pehli baar 5-10 min lag sakte hain, internet chahiye).

## Step 3: Free Gemini API key lo
1. https://aistudio.google.com par jao, Google account se login karo.
2. **Get API Key** par click karo, naya key generate karo. Credit card nahi maangega.
3. Key copy kar lo.

## Step 4: App run karo
- Apna Android phone USB se connect karo, aur phone mein **Developer Options** + **USB Debugging** on karo
  (Settings > About Phone > Build Number par 7 baar tap karo to Developer Options unlock hota hai).
- Android Studio mein green **Run ▶** button dabao, phone select karo.
- App khulne ke baad **Settings** button dabao, apni Gemini key paste karo, **Save** karo.
- Mic permission, Call permission, SMS permission, Contacts permission allow karo jab poocha jaaye.

## Use kaise karein
Mic button dabao aur bolo, jaise:
- "Mummy ko call karo" (agar contact mein wo naam saved hai)
- "WhatsApp kholo"
- "Alarm laga do"
- "Cricket score search karo"
- Ya kuch bhi normal baat — wo Gemini AI se reply karega, jaise insaan bolta hai

## Important baatein
- **Ye sirf tumhare phone par chalega** — Play Store par publish karne ke liye Google ki extra
  approval chahiye hoti hai (CALL/SMS jaisi "restricted permissions" ke liye), lekin apne personal
  use ke liye sideload karna bilkul theek hai.
- Command samajhna abhi **simple keyword-matching** se ho raha hai (perfect AI samajh nahi hai).
  Agar tum chaho to ye aur smart banaya ja sakta hai — Gemini ko hi bol sakte hain ki command
  decide kare (function calling), bata dena agar wo upgrade chahiye.
- Female voice device ki installed TTS voices par depend karta hai. Agar awaaz acchi nahi lage,
  to Settings > Apps > Google Text-to-Speech mein jaake Hindi/English female voice download kar lo.
- Gemini free tier mein roz ki limit hai (~1000+ requests/day) — normal personal use ke liye kaafi hai.

## Agar kuch aur add karwana ho
Ye ek MVP (starting version) hai. Aage isme ye sab add ho sakta hai:
- WhatsApp par directly message bhejna
- Reminders jo notification de
- Wake word ("Hey Jarvis") se bina button dabaye activate hona
- Better natural language understanding
